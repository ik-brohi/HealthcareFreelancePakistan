import 'package:ecom/Widgets/responsive.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'Widgets/favouriteproduct.dart';

class Favourite extends StatefulWidget {
  @override
  State<Favourite> createState() => _FavouriteState();
}

class _FavouriteState extends State<Favourite> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0.0,
        backgroundColor: Colors.grey[50],
        //    leading: Icon(Icons.close),
        iconTheme: IconThemeData(color: Colors.black),
      ),
      body: SafeArea(
          child: SingleChildScrollView(
        child: Container(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Align(
                  alignment: Alignment.topLeft,
                  child: Text(
                    "Favourite",
                    style: GoogleFonts.openSans(
                        color: Colors.black,
                        fontSize: 30.0,
                        fontWeight: FontWeight.bold),
                  ),
                ),
              ),
              SizedBox(height: countHeight(25, context)),
              favproducts("Images/tshirt1.jpeg", "T-shirt", "Plaine tshirt",
                  "999", context),
              favproducts("Images/tshirt4.jpeg", "T-shirt", "Plaine tshirt",
                  "999", context),
              favproducts("Images/tshirt3.jpeg", "T-shirt", "Plaine tshirt",
                  "999", context),
            ],
          ),
        ),
      )),
    );
  }
}
